<?php
class Part3O
{
    var $mp3url;
    var $transcript;
    var $transimg;
    var $questID;
    var $testID;

    var $quest;
    var $trueans;
    var $ansa;
    var $ansb;
    var $ansc;
    var $ansd;

    var $quest1;
    var $trueans1;
    var $ansa1;
    var $ansb1;
    var $ansc1;
    var $ansd1;
    
    var $quest2;
    var $trueans2;
    var $ansa2;
    var $ansb2;
    var $ansc2;
    var $ansd2;

    var $quest3;
    var $trueans3;
    var $ansa3;
    var $ansb3;
    var $ansc3;
    var $ansd3;

    var $quest4;
    var $trueans4;
    var $ansa4;
    var $ansb4;
    var $ansc4;
    var $ansd4;

    var $quest5;
    var $trueans5;
    var $ansa5;
    var $ansb5;
    var $ansc5;
    var $ansd5;

    function setmp3url($mp3url){
        $this->mp3url = $mp3url;
    }

    function getmp3url(){
        return $this->mp3url;
    }

    function settranscript($transcript){
        $this->transcript = $transcript;
    }

    function gettranscript(){
        return $this->transcript;
    }

    // ---------

    function setquestID($questID){
        $this->questID = $questID;
    }

    function getquestID(){
        return $this->questID;
    }

    function settestID($testID){
        $this->testID = $testID;
    }

    function gettestID(){
        return $this->testID;
    }

    function setquest1($quest1){
        $this->quest1 = $quest1;
    }
    function settrueans1($trueans1){
        $this->trueans1 = $trueans1;
    }
    function setansa1($ansa1){
        $this->ansa1 = $ansa1;
    }
    function setansb1($ansb1){
        $this->ansb1 = $ansb1;
    }
    function setansc1($ansc1){
        $this->ansc1 = $ansc1;
    }
    function setansd1($ansd1){
        $this->ansd1 = $ansd1;
    }

    function setquest2($quest2){
        $this->quest2 = $quest2;
    }
    function settrueans2($trueans2){
        $this->trueans2 = $trueans2;
    }
    function setansa2($ansa2){
        $this->ansa2 = $ansa2;
    }
    function setansb2($ansb2){
        $this->ansb2 = $ansb2;
    }
    function setansc2($ansc2){
        $this->ansc2 = $ansc2;
    }
    function setansd2($ansd2){
        $this->ansd2 = $ansd2;
    }

    function setquest3($quest3){
        $this->quest3 = $quest3;
    }
    function settrueans3($trueans3){
        $this->trueans3 = $trueans3;
    }
    function setansa3($ansa3){
        $this->ansa3 = $ansa3;
    }
    function setansb3($ansb3){
        $this->ansb3 = $ansb3;
    }
    function setansc3($ansc3){
        $this->ansc3 = $ansc3;
    }
    function setansd3($ansd3){
        $this->ansd3 = $ansd3;
    }

    function setquest4($quest4){
        $this->quest4 = $quest4;
    }
    function settrueans4($trueans4){
        $this->trueans4 = $trueans4;
    }
    function setansa4($ansa4){
        $this->ansa4 = $ansa4;
    }
    function setansb4($ansb4){
        $this->ansb4 = $ansb4;
    }
    function setansc4($ansc4){
        $this->ansc4 = $ansc4;
    }
    function setansd4($ansd4){
        $this->ansd4 = $ansd4;
    }

    function setquest5($quest5){
        $this->quest5 = $quest5;
    }
    function settrueans5($trueans5){
        $this->trueans5 = $trueans5;
    }
    function setansa5($ansa5){
        $this->ansa5 = $ansa5;
    }
    function setansb5($ansb5){
        $this->ansb5 = $ansb5;
    }
    function setansc5($ansc5){
        $this->ansc5 = $ansc5;
    }
    function setansd5($ansd5){
        $this->ansd5 = $ansd5;
    }

    // -------------------

    function getquest1(){
        return $this->quest1;
     }
     function gettrueans1(){
        return $this->trueans1;
     }
     function getansa1(){
        return $this->ansa1;
     }
     function getansb1(){
        return $this->ansb1 ;
     }
     function getansc1(){
        return $this->ansc1 ;
     }
     function getansd1(){
        return $this->ansd1 ;
     }
     function getquest2(){
        return $this->quest2;
     }
     function gettrueans2(){
        return $this->trueans2;
     }
     function getansa2(){
        return $this->ansa2;
     }
     function getansb2(){
        return $this->ansb2 ;
     }
     function getansc2(){
        return $this->ansc2 ;
     }
     function getansd2(){
        return $this->ansd2 ;
     }
     function getquest3(){
        return $this->quest3;
     }
     function gettrueans3(){
        return $this->trueans3;
     }
     function getansa3(){
        return $this->ansa3;
     }
     function getansb3(){
        return $this->ansb3 ;
     }
     function getansc3(){
        return $this->ansc3 ;
     }
     function getansd3(){
        return $this->ansd3 ;
     }
     function getquest4(){
        return $this->quest4;
     }
     function gettrueans4(){
        return $this->trueans4;
     }
     function getansa4(){
        return $this->ansa4;
     }
     function getansb4(){
        return $this->ansb4 ;
     }
     function getansc4(){
        return $this->ansc4 ;
     }
     function getansd4(){
        return $this->ansd4 ;
     }
     function getquest5(){
        return $this->quest5;
     }
     function gettrueans5(){
        return $this->trueans5;
     }
     function getansa5(){
        return $this->ansa5;
     }
     function getansb5(){
        return $this->ansb5 ;
     }
     function getansc5(){
        return $this->ansc5 ;
     }
     function getansd5(){
        return $this->ansd5 ;
     }

}

?>