<div class="col-sm-8 col-md-9 main-cont">
    <!-- San pham -->
    <div class="row content-detail">
        <div class="row tab tab-icon">
            Đặt hàng
        </div>

        <div class="thumbnail">
            <img src="<?php echo base_url()?>public/imgs/success.jpg">
        </div>

    </div>

</div>
</div>