<div class="container bg404">
    <a href="<?php echo base_url() ?>"><img src="<?php echo base_url() ?>public/imgs/404-cat.gif" class="img-fluid"></a>
    <h2 class = "txt404"><a href="<?php echo base_url() ?>">Oops... looks like you got lost!
        </a>
    </h2>
</div>


