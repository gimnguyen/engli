<?php
/**
 * Created by PhpStorm.
 * User: Gim
 * Date: 7/21/2018
 * Time: 1:39 PM
 */

class part5question
{
    public $question;
    public $answerA;
    public $answerB;
    public $answerC;
    public $answerD;
    public $trueAns;

}

