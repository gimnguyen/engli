</div>
<!-- /.container -->

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="<?php echo base_url()?>public/js/jquery-3.1.1.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url()?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>public/ckeditor/ckeditor.js"></script>
</body>

</html>