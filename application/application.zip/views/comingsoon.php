<div class="container gcoming">
    <a href="<?php echo base_url() ?>"><img src="<?php echo base_url() ?>public/imgs/coding.gif" class="img-fluid"></a>
    <h2 class="tx-ye">It's coming!</h2>
</div>